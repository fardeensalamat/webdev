<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    
    <div class="data_check">
        <div></div>
    </div>



    <script>
        getLocation();
        function getLocation(){
            if(navigator.geolocation){
                navigator.geolocation.getCurrentPosition(showPosition,errorMassage);
            }else{
                alert('Browser Not Supporting');
            }
        }
        function errorMassage(error){
            alert(error.message);
        }
        function showPosition(position){
            let lat = position.coords.latitude;
            let lon = position.coords.longitude;
            console.log(lat);
            console.log(lon);

            // axios.post('/getProduct',{
            //     lat:lat,
            //     lon:lon,
            // })
            // .then(function(response){
            //     $('.productItemShow').empty();
            //     let jsonData = response.data; 
            //     console.log(jsonData);
            //     $.each(jsonData, function(i,item){
            //         $('<div class="col-lg-3 mb-4">').html(
            //             '<div class="puduct-item border">'+
            //                     '<img src="'+jsonData[i].product_img+'" alt="Images" class="w-100">'+
            //                     '<div class="product-content py-3 px-2">'+
            //                         '<p>'+jsonData[i].shop_name+'</p>'+
            //                         '<h5><b>'+jsonData[i].product_name+'</b></h5>'+
            //                         '<h5><em>'+jsonData[i].product_price+'</em> /=</h5>'+
            //                     '</div>'+
            //                 '</div>'
            //         ).appendTo('.productItemShow');
            //     })
            // })  
            // .catch(function(error){
            //     console.log('Error')
            // })

        }



    </script>
</body>
</html>